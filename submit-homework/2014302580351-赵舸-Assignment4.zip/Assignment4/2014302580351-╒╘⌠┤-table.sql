/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50624
Source Host           : 127.0.0.1:3306
Source Database       : my_schema

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2015-11-19 19:53:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for 2014302580351_professor_info
-- ----------------------------
DROP TABLE IF EXISTS `2014302580351_professor_info`;
CREATE TABLE `2014302580351_professor_info` (
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `researchInterests` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
