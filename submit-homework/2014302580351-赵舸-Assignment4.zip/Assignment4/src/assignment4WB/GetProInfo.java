package assignment4WB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GetProInfo {
//�����ݿ�ȡ������
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				Connection con = DriverManager
						.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
				return con;
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
//�����ݿ���ȡ�ý�����Ϣ�������䴢��Ϊһ����Ϊproinfolist������
	public ArrayList<professorinfo> getproinfo() {
		ArrayList<professorinfo> proinfolist = new ArrayList<professorinfo>();
		Connection con = this.getConnection();
		PreparedStatement s = null;
		ResultSet rs = null;
		try {
			s = con.prepareStatement("SELECT * FROM 2014302580351_professor_info;");
			rs = s.executeQuery();
			while (rs.next()) {
				professorinfo proinfo = new professorinfo(rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5));
				proinfolist.add(proinfo);
			}
			return proinfolist;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (s != null) {
					s.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
