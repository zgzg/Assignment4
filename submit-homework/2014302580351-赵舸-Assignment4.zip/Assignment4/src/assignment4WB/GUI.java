package assignment4WB;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import net.miginfocom.swing.MigLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class GUI {

	private JFrame frame;
	private JTextField textField;
	private JTextArea textArea;
	private String keywords;
//������
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
//gui�Ĺ��캯��
	public GUI() {
		initialize();
	}

	private void initialize() {
		FindProInfo searchplaceex = new FindProInfo();

		frame = new JFrame();
		frame.setTitle("��������");
		frame.setBounds(100, 100, 515, 411);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		textArea = new JTextArea();
		textArea.setBounds(10, 85, 463, 259);
		textArea.setLineWrap(true);
//������ť���������¼�������
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(361, 10, 88, 35);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Boolean notfind = true;
				textArea.setText("");
				keywords = textField.getText().trim();
				searchplaceex.getKeyword(keywords);
				searchplaceex.calTf();
				ArrayList<professorinfo> searchresultList = searchplaceex.sort();
				for (professorinfo searchresult : searchresultList) {
					if (searchresult.tf > 0) {
						textArea.append(searchresult.name + "\n" + searchresult.educationBackground + "\n"
								+ searchresult.researchInterests);
						notfind = false;
					}
				}
				if (notfind) {
					textArea.append("Sorry,I can not find what you want.");
				}
			}

		});
		panel.add(btnSearch);

		textField = new JTextField();
		textField.setBounds(103, 10, 251, 35);
		panel.add(textField);
		textField.setColumns(10);
		JScrollPane scrollpane = new JScrollPane(textArea);
		scrollpane.setBounds(10, 85, 463, 259);
		panel.add(scrollpane);

		JLabel lblInput = new JLabel("Keywords:");
		lblInput.setFont(new Font("����", Font.PLAIN, 18));
		lblInput.setBounds(10, 10, 83, 35);
		panel.add(lblInput);

		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("����", Font.PLAIN, 18));
		lblResult.setBounds(10, 55, 88, 20);
		panel.add(lblResult);

	}
}
