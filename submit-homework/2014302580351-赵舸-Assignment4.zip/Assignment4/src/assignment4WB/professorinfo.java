package assignment4WB;
// professorinfo ��  ���ڱ�������ݿ��ж�ȡ�Ľ�����Ϣ
public class professorinfo {
	public String name;
	public String educationBackground;
	public String researchInterests;
	public String email;
	public String phone;
	public double tf;

	public professorinfo(String name, String educationBackground, String researchInterests, String email,
			String phone) {
		this.name = name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.email = email;
		this.phone = phone;
		this.tf = 0;
	}
//�������ô�Ƶ
	public void settf(double tf) {
		this.tf = tf;
	}
}
