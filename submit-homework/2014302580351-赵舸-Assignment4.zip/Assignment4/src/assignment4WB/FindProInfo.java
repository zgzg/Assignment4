package assignment4WB;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
//���ؼ����������Ϣƥ���Եõ���Ҫ�Ĳ�ѯ���
public class FindProInfo {
	public GetProInfo getproinfo = new GetProInfo();
	public ArrayList<professorinfo> proinfolist = getproinfo.getproinfo();
	public ArrayList<String> searchplace = new ArrayList<String>();
//���ڽ�������ı����string���͵�����
	public void getKeyword(String text) {
		String[] keyword = text.split("\\s");
		searchplace = new ArrayList<String>(Arrays.asList(keyword));
	}
//���ڼ���tfֵ
	public void calTf() {
		for (professorinfo proinfoex : proinfolist) {
			double x = 0;
			double tf = 0;
			for (String Keyword : searchplace) {
				String[] allname = proinfoex.name.split("\\s");
				for (String name : allname) {
					if (name.equals(Keyword))
						x += 1;
				}
				String[] allEducationBackground = proinfoex.educationBackground.split("\\s");
				for (String educationBackground : allEducationBackground) {
					if (educationBackground.equals(Keyword))
						x += 1;
				}
				String[] allresearchInterest = proinfoex.researchInterests.split("\\s");
				for (String researchInterest : allresearchInterest) {
					if (researchInterest.equals(Keyword))
						x += 1;
				}
				tf = x / searchplace.size();
				((professorinfo) proinfoex).settf(tf);
			}
		}
	}
//����tf��proinfo����
	public ArrayList<professorinfo> sort() {
		SearchResultComparator src = new SearchResultComparator();
		Collections.sort(proinfolist, src);
		return proinfolist;
	}

	class SearchResultComparator implements Comparator<professorinfo> {
		public int compare(professorinfo sr1, professorinfo sr2) {
			if (sr1.tf > sr2.tf)
				return 1;
			else if (sr1.tf < sr2.tf)
				return -1;
			else 
				return 0;
		}

	}
}
